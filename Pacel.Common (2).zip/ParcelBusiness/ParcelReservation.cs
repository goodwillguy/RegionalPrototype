﻿using Pacel.Common.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tz.ParcelModel_Singapore;

namespace ParcelBusiness_Singapore
{
    public class ParcelReservation:IParcelReservation
    {

        public bool CreateParcel()
        {
            ParcelDbContext_Singapore db = new ParcelDbContext_Singapore();

            Parcel p = new Parcel();
            p.Id = Guid.NewGuid();

            p.ParcelId = Guid.NewGuid().ToString();
            p.OrderNumber = "1234";

            db.Parcels.Add(p);

            db.SaveChanges();
            return false;
        }


        public string GetFirstParcel()
        {

            ParcelDbContext_Singapore db = new ParcelDbContext_Singapore();
            var firstParcel=db.Parcels.FirstOrDefault();
            if(firstParcel!=null && firstParcel.OrderNumber=="1234")
            {
                return "Singapore";
            }

            return "Non-Singapore";
        }
    }
}
