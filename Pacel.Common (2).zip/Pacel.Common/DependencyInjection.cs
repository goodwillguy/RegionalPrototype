﻿using Pacel.Common.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pacel.Common
{
    public class DependencyInjection
    {

        public void RegisterClasses(SimpleInjector.Container container)
        {

        }
    }
}
